
MERRY CHRISTMAS 2006 FROM TASMODIA

Hi everybody,

all presets in this package are copyright by tasmodia and are free for use in your music. However, you are not allowed to sell, distribute or include them in other packages.

Now have fun with the sounds!

Thomas

