From JeeTee on KVR:

I like Zebra. In fact I like it a lot! But I've always been
slightly frustrated by the way it handles sync. A lot of
synths require 2 oscillators synced together to make these
sounds, whereas Zebra has a dedicated sync function which
gives you.... well, one flavour of sync. I decided to see
if I could program some more flavours using Zeb's wavetables,
and here are the results:

Saw Sync WT.h2p
Square Sync WT.h2p
Triangle Sync WT.h2p

The saw and triangle syncs span 3 octaves, the square only 2
as there's a limit of 33 points that can be added to a geomorph
wave.

Happy Sync-ing!