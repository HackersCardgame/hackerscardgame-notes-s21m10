Thanks for downloading this preset mini pack for U-he Zebra.
I used Wav2Zebra2Java for export a sampled waveforms, and also s(M)exoscope to analyse and result correcting.

00 Sylenth1 waveset.h2p is raw oscillator preset without settings, it contains all the basic waveforms generating by Sylenth1 (EXCEPT white noise).
--------------------------------------------------------------

All of theese

01 Sylenth1 sine.h2p
02 Sylenth1 saw.h2p
03 Sylenth1 triangle.h2p
04 Sylenth1 pulse.h2p
05 Sylenth1 hpulse.h2p
06 Sylenth1 qpulse.h2p
07 Sylenth1 trisaw.h2p

have minimal OscFX settings for more similarities to Sylenth1.


Serhiy.



