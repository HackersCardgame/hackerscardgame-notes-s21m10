Here are some of my recent experiments: 

-70s Jet Car A cool "bubbly" oscfx combination that sorta sounds like 
the Jetsons car or a Robocop NES SFX. ModWhl for rate (you don't have to 
max it out) 

-Custom Resonant Peak Deactivate OSC2 for a moment to get the picture 
Prototype filter designer 

-Impulse Modulated pulse wave to get a cool suction punch 

-Phaser to Chorus Just found out that you can trick the ModFX phaser to 
sound more like a BBD? type chorus. No extra modulations are necessary.. 
but couldn't help myself modulating the Quad Phase with LFO1. Enable 
ModFX2 to get a thicker tone. 

-Sequencer MM1 for pitch and MM2 for volume... can use it as a vintage 
CV seq or for sketching chip sequences. Control the rate with MSEG4 
"loop". Change the sequence direction and revolution curve if you wish. 
Up to 128 MMap steps, mixable and pitch quantizable ^ ^ You have to play 
with this one... it's lots of fun! 

-Star Hold a note and look at an phase vector scope (stereo scope) some 
notes can be added to form more complex visual patterns. 

