Bell Builder can give you anything from a glass lid
to a large church bell, depending upon the chord you play.

Note the use of SB filters and the way "soft reverb" is
done here.

-Howard Scarr