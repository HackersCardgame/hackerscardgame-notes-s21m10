This is a compilation of sounds making use of Zebra's comb filters.  It is mostly a variety of percussion, pads, and sound effects.  My intention was to have a little pallete of sounds for those who produce sounds for film, but of course, you can use them in any way that you like.
You most likely need version 2.5, since I made the patches in 2.5 mode.
Just drop this in your Zebra presets folder, the path to which might look something like this:

E:\Program Files (x86)\VstPlugins\u-he\Zebra2.data\Presets\Zebra2

You're free to use them in any way you like, commercially if need be.
I always appreciate comments of any color(friendly preffered:)), so feel free to drop me a line at Esgalachoir@yahoo.com
or you can private message me as Esgalachoir on KVRAudio.com

Thanks and have fun!

 - Corin