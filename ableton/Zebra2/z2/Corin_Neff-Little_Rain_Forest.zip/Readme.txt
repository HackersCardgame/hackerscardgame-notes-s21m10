Just Put this folder into your Zebra Presets folder

The path should be something like this if you're running Zebra2 in 64bit:

C:\Program Files\VSTPlugins\u-he\Zebra2.data\presets\Zebra2

For Zebra2 32bit:

C:\Program Files(x86)\VSTPlugins\u-he\Zebra2.data\presets\Zebra2
