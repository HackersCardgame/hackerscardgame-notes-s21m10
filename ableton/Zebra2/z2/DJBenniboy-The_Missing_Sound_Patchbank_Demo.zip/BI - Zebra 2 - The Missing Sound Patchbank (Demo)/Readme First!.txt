BI (Ben Insole) - The Missing Sound Patchbank (Demo)

Description: Famous sounds from the 90's that will trully deliver in your mix from Ben Insole(B.I), A Demo collection of Rave/Dance/Tech Sounds from that era that you were missing from that "Just Good Mix"

NEWS 

Here is the good news.... :)

Still a Demo. But as I Have been working hard and feel preety good about these sounds, I thought Id let you hear other sounds that I am capable of designing, Sounds that capture the essence of the REAL sound from synth/author and have been marked up with (Live) by the side of the patch....Also I have categorised the patches, even in this demo version....so do not be surprised to see not allot of sounds in that particular category, There are many sounds as you know in the LEAD section...as soon as the bank is finished, I will create a list of sounds that are available in each bank...So it shall be easier for you all :)....

*SYSTEM REQUIREMENTS

Windows XP(32/64)w/sp3 or Windows 7(32/64) SP1
Hard Disk Space (20MB) at Least free
2GB Of RAM
An "ASIO" compliant Soundcard(1)*
At Least an AMD Athlon X2 or Intel equivalent dualcore processor @3Ghz(2)*
Any Host that will run ZEBRA 2 

(Read notes for * Below for great usage instructions)


INSTALLATION:

Note: During Install, Replace (X) with the drive letter of you harddisk/s

Please Install These Patches to : (X)ProgramFiles\VstPlugins\u-he\Zebra2.data\Presets\ - Drop the Folder named " Zebra 2 - The Missing Sound Patchbank(Demo)" into this folder, go into your host and the folder should be there, If not right-click on an empty part of Zebra 2 and click on the menu that comes up "Refresh Folder List" hopefully the bank should then appear :).... may I remind users, This is a demo Patchbank and atmost care and skillfull listening has been required to make these patches sound really good, Some of the Patches Use X/Y and some use Lfo/Modulations via Mod wheel, while a few dont.....I am still working on this superb collection of sounds and will require allot of listening and man hours to create the full bank of sounds! :) I hope you appreciate the time that has gone into the Demobank already :)...thank you for a lovely community at KVR Forums....Follow me @  DJBenniboy on KVR and also check out my music @ http://www.soundcloud.com/benniboyproductions


Note "*" (1) An ASIO driver soundcard is "ALWAYS" better for audio production that standard "onboard" sound, but if you want to risk spikes/glitches in sound and CPU usage....goto the ASIO4ALL website @ http://www.asio4all.com and download the latest, also the latest soundcard drivers should help performance.(2)I recommend at least a Dual core Intel or AMD Dual-core cpu...because with some of these patches, they are CPU bound, and even though a lot of efforts have gone into making the sounds as CPU friendly as possible, it's always good to warn you....instead of you asking on KVR questions like "why am I getting spikes or audio dropouts while using sucha sucha patch"....this is your reason and preety much answers your question! :D...

