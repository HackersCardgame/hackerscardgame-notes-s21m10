Just some fun patches I wanted to share. Some are attempts at recreations while others are just plain wacky. Some have playing info such as BPM & note ranges within the preset.

Also check out my Zebrosis bank at my website. Have fun!

Cheers,

Ed Ten Eyck
www.edtaudio.com