Just Put this folder into your Zebra Presets folder

The path should be something like this if you're running Zebra2 in 64bit:

C:\Program Files\VSTPlugins\u-he\Zebra2.data\presets\Zebra2

For Zebra2 32bit:

C:\Program Files(x86)\VSTPlugins\u-he\Zebra2.data\presets\Zebra2

Project Xebra is a collection of experimental soundscapes, glitchy, grungy, and complex sequences,
Wobbly, experimental basses, some bread and butter synths, some mallets, and some animal soundscapes.
I hope you find them useful and enjoyable!



You may not redistrubute or resell this set of sounds in any way, shape or form.  
You may not resell or redistribute any of the patches
within this soundbank in any way, shape, or form.  You may not sell or redistribute 
any modified version of the set of sounds or individual patches
in any way, shape or form.