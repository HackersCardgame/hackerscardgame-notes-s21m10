Here's my init patch, OSC3 is containing the DCO Wavetable.
(note: it's not an osc preset but a normal patch, so load
 accordingly, than you can save your desired wavetable(s)
 from there as on osc preset or use the whole patch)

The real secret to super solid, sharp or blur-fuzzy-silky-digi-smooth
yet still super solid timbres.

Perfect phase relationship on a combination of phase synced good waves.
Volume helps shape the wave as well (basically, as you go up in pitch
with one osc, you lower it's volume to blend it into one perceived timbre)

No more harsh or brittleness on attack/transients and polyphony.

-3ee