Hi there

Here is all free patches i've made available over the years with Zebra VST.

You can use them freely but not re-distribute them in any form and
sampling the sounds is a big NO NO. Thats reserved for me to do.

Some are patches from the oldskool soundsets, some are from competitions
and some are from things i want to make people aware of like the little
FM school and ways to use MSEG's.

/Michael Kastrup Aug 2010

www.xsynth.com