----Pixelations DEMO - Zebra 2 Soundset by Complex-------------------------------------------------
----For Zebra 2 by U-He----------------------------------------------------------------------------

----WARNING!---------------------------------------------------------------------------------------

Please lower your monitors and headphones volumes if are high, sometimes resonant filters work too loud and can harm your ears and your equipment.

----DEMO-------------------------------------------------------------------------------------------

This is a 8 patches DEMO. If you like this sounds you can download the full soundset with 128 patches from here:
http://www.zensound.es/soundsets/zebra-2-pixelations/

----Installation-----------------------------------------------------------------------------------

Copy the folder 'Pixelations' in this route. 
(Your Zebra 2 installation folder)..\u-he\Zebra2.data\Presets\Zebra2

If you don't find the Zebra 2 installation folder then try do a search for *.H2P files on your computer.

----Contact----------------------------------------------------------------------------------------

http://soundcloud.com/complex_sound
http://zensound.es
info@zensound.es

---------------------------------------------------------------------------------------------------

Please let me know if I have things to improve, change or simply ask a question.

Thanks for supporting ZenSound, Complex | Adrian Jimenez.
