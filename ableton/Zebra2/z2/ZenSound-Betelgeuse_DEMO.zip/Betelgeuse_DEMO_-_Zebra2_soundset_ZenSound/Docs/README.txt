----Betelgeuse DEMO - Zebra2 Soundset by ZenSound-------------------------------------------------

This is a 11 patches DEMO. If you like these sounds you can download the full soundset with 150 
patches from here: 

http://www.zensound.es/soundsets/zebra-betelgeuse/

----Installation----------------------------------------------------------------------------------

Mac

Go to the folder 'Presets' and copy the folder 'ZenSound - ZEBRA BETELGEUSE' in this route. 
MacHD/Library/Audio/Presets/u-he/Zebra/

Windows

Go to the folder 'Presets' and copy the folder 'ZenSound - ZEBRA BETELGEUSE' in this route.
...\VstPlugins\Zebra.data\Presets\Zebra\


----Contact---------------------------------------------------------------------------------------

http://zensound.es
info@zensound.es

--------------------------------------------------------------------------------------------------

