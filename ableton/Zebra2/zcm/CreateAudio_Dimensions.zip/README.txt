Thank you for downloading Create:Audio Presets. www.createaudio.wordpress.com
LICENSE:

This work is licensed under the Creative Commons Attribution-Share Alike 3.0 Unported License. To view a copy of this license, visit http://creativecommons.org/licenses/by-sa/3.0/


WARNING:

Create:Audio warns the user  that it may contain harsh and piercing sounds. Lower your monitors and headphones before previewing them and using them. Use at your own risk. 




DO NOT: Sell these presets or compile them with others & release them. If you have questions I can be reached at createaudio. 




SHOW YOUR SUPPORT!

Please visit & bookmark

http://createaudio.wordpress.com/

for more samples & presets. 

Please ADD The Ghost Station to your FRIENDS ON MYSPACE
www.myspace.com/ghoststationmusic

Download my free Album while you are there!

