MC ZebraCM 2010: 143 Zebra CM presets by Michael Cavallo
Released on 02-14-10

Update information: 
  1. Compiled all presets from MC ZebraCM Sets 1-3 into one package.
  2. Added 5 new presets.
  3. Changes made to Modulation Wheel settings of various lead presets.
  4. Tweaked certain presets, and their FX.
  5. All presets are now H2P files only.

Enjoy.
