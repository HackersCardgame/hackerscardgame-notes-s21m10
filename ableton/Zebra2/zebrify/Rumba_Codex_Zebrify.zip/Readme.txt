Rumba Codex Zebrify 001 

Here are some experiments of mine ...  

You'll want to try different Input settings with these, for example: 
[Input] > Pitch Detector > Mode = Percussive 
Play with HiNote & LowNote values etc ... 
[MIDI] > KeySource = Input (great with loops) or MIDI