Hi
This patches are some factory "sound/preset" modified (_m). There's some news also.
Author : Jeff
Contact : snail25@free.fr
web : http://maopassion.free.fr

come from time to time, new banks are added regularly .

