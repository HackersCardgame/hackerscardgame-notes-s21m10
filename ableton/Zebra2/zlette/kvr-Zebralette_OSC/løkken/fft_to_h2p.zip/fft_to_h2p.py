import argparse


NUM_SAMPLES = 256


class Spectrum:
    def __init__(self):
        self._points = [(0.0, 0.0), (176400.0, 0.0)]

    def __call__(self, frequency):
        previous_point = next(
            point for point in self._points if point[0] <= frequency)
        next_point = next(
            point for point in self._points if point[0] > frequency)

        frequency_range = next_point[0] - previous_point[0]
        amplitude_range = next_point[1] - previous_point[1]

        return (previous_point[1] + amplitude_range *
            (frequency - previous_point[0]) / frequency_range)

    def add_band(self, frequency, amplitude):
        self._points.append((frequency, amplitude))
        self._points = sorted(self._points)

    def normalize(self):
        max_amplitude = max(self._points, key=lambda point: point[1])[1]
        self._points = [
            (point[0], point[1] / max_amplitude) for point in self._points]


def load_spectrum(filename):
    parameters = {}
    spectrum = Spectrum()

    band_index = 0

    with open(filename, "r") as input_file:
        for line in input_file.readlines():
            line = line.strip()

            if not line:
                continue

            if "=" in line:
                parameter_name, parameter_value = line.split("=")
                parameters[parameter_name] = parameter_value
            else:
                min_frequency = float(parameters["freqstart"])
                max_frequency = float(parameters["freqstop"])
                frequency_interval = max_frequency - min_frequency

                num_frequencies = int(parameters["number"])

                frequency = (
                    min_frequency + frequency_interval *
                        band_index / (num_frequencies - 1))
                amplitude = float(line)

                spectrum.add_band(frequency, amplitude)

                band_index += 1

    spectrum.normalize()

    return spectrum


def convert_to_harmonic_table(spectrum, fundamental_frequency):
    harmonic_table = []

    for index in range(NUM_SAMPLES):
        frequency = fundamental_frequency * (index + 1)
        harmonic_table.append(spectrum(frequency))

    return harmonic_table


def save_harmonic_tables(tables, filename):
    with open(filename, "w") as output_file:
        print("#defaults=no", file=output_file)
        print("#cm=OSC", file=output_file)
        print("Wave=3", file=output_file)
        print("<?", file=output_file)
        print("float Wave[ {} ];".format(NUM_SAMPLES), file=output_file)

        for table_index, table in enumerate(tables):
            max_amplitude = max(harmonic * (harmonic_index + 1) for
                harmonic_index, harmonic in enumerate(table))

            for harmonic_index, harmonic in enumerate(table):
                print(
                    "Wave[ {} ] = {:.16f};".format(
                        harmonic_index,
                        harmonic * (harmonic_index + 1) / max_amplitude),
                    file=output_file)

            print(
                "Selected.WaveTable.set( {} , Wave );".format(table_index + 1),
                file=output_file)
            print("", file=output_file)

        print("?>", file=output_file)


def main():
    parser = argparse.ArgumentParser(
        description="Convert from 1 to 16 .fft files into an .h2p file")
    parser.add_argument(
        "-i", dest="input", type=str, nargs="+", help="input .fft file",
        required=True)
    parser.add_argument(
        "-o", dest="output", type=str, help="output .h2p file",
        required=True)
    parser.add_argument(
        "-f", dest="fundamental", type=float,
        help="fundamental frequency in Hz",
        required=True)

    args = parser.parse_args()

    spectrums = [
        load_spectrum(filename) for filename in args.input]

    harmonic_tables = [
        convert_to_harmonic_table(spectrum, args.fundamental) for
            spectrum in spectrums]

    save_harmonic_tables(harmonic_tables, args.output)


if __name__ == "__main__":
    main()
