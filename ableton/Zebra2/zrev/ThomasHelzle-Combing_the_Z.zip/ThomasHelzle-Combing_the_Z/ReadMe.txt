"Combing the Z"

25 Presets in .fxp format for ZRev - part of U-He Zebra.

ZRev is seeing little love from preset creators so I thought I'd offer 25 of mine that I created a while ago. Many of them focus on comb-like effects, therefore the name.

Hint: Especially changing the "Size" parameter can drastically change the tone, so be sure to play with that.

All the presets are free to use and abuse.

Enjoy :-)

Cheers,

Thomas Helzle
http://www.screendream.de